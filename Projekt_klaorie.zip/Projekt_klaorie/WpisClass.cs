﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_klaorie
{
    internal class WpisClass
    {
        public int ID { get; set; }
        public int ID_Osoba { get; set; }
        public int ID_Sport { get; set; }
        public int ID_Potrawa { get; set; }
        public string Typ { get; set; }
        public int czas { get; set; }
        public DateTime Data { get; set; }
    }
}
